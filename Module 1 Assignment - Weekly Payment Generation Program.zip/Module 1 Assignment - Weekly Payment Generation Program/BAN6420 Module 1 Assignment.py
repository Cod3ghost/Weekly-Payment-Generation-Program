import random

# Define a Worker class for better structure
class Worker:
    def __init__(self, id, name, gender, salary):
        self.id = id
        self.name = name
        self.gender = gender
        self.salary = salary
        self.level = None

    def determine_employee_level(self):
        try:
            if 10000 < self.salary < 20000:
                self.level = "A1"
            if 7500 < self.salary < 30000 and self.gender == "F":
                self.level = "A5-F"
        except Exception as e:
            print(f"Error determining employee level for worker {self.id}: {e}")

    def generate_payment_slip(self):
        try:
            slip = f"Payment Slip for {self.name} (ID: {self.id})\n"
            slip += f"Salary: ${self.salary}\n"
            slip += f"Level: {self.level}\n"
            return slip
        except Exception as e:
            print(f"Error generating payment slip for worker {self.id}: {e}")

# Function to generate a list of workers dynamically
def generate_workers(num_workers=400):
    workers = []
    for i in range(1, num_workers + 1):
        # Randomly generate worker's name, gender, and salary
        name = f"Worker-{i}"
        gender = random.choice(["M", "F"])
        salary = random.randint(5000, 30000)
        worker = Worker(id=i, name=name, gender=gender, salary=salary)
        worker.determine_employee_level()
        workers.append(worker)
    return workers

# Main code
workers = generate_workers()

# Generate payment slips for all workers
for worker in workers:
    print(worker.generate_payment_slip())
