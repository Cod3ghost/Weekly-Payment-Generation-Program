generate_payment_slips <- function() {
  workers <- list()
  
  # Creating 400 workers dynamically
  for (i in 1:400) {
    worker_id <- paste("Worker_", i, sep = "")
    salary <- sample(5000:35000, 1)
    gender <- sample(c("Male", "Female"), 1)
    
    # Default employee level
    employee_level <- "Unassigned"
    
    # Conditional checks to determine employee level
    if (salary > 10000 && salary < 20000) {
      employee_level <- "A1"
    } else if (salary > 7500 && salary < 30000 && gender == "Female") {
      employee_level <- "A5-F"
    }
    
    # Store worker details
    worker <- list(
      ID = worker_id,
      Salary = salary,
      Gender = gender,
      Employee_Level = employee_level
    )
    
    workers[[i]] <- worker
  }
  
  # Generate payment slips for each worker
  for (worker in workers) {
    tryCatch({
      cat("Generating payment slip for", worker$ID, "\n")
      cat("Salary:", worker$Salary, "\n")
      cat("Gender:", worker$Gender, "\n")
      cat("Employee Level:", worker$Employee_Level, "\n\n")
    }, error = function(e) {
      cat("Error occurred while processing worker", worker$ID, ":", e$message, "\n")
    })
  }
}

# Call the function
generate_payment_slips()
